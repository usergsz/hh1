import cv2
import socket
import threading
import tkinter as tk

from PIL import Image,ImageTk
from FaceRecognition import Face
from matplotlib.figure import Figure  #图
import matplotlib.pyplot as plt #表

def face_img(face_p):
    global photo1
    photo_open1=Image.open('./'+face_p+'.jpg') #image打开
    photo1=photo_open1.resize((120,120))# 自己扩大
    photo1=ImageTk.PhotoImage(photo1)#imtk扩大图片
    tk.Label(Frame2,image=photo1).place(x=50,y=50)# label显示frame2
def ewm_img(ewm_p):
    global photo2
    photo_open2=Image.open('./'+ewm_p+'.jpg')
    photo2=photo_open2.resize((100,100))
    photo2=ImageTk.PhotoImage(photo2)
    tk.Label(Frame3,image=photo2).place(x=50,y=80)
def sx_img(sx_photo):
    global photo3
    photo_open3=Image.open('./'+sx_photo+'.jpg')
    photo3=photo_open3.resize((400,400))
    photo3=ImageTk.PhotoImage(photo3)
    tk.Label(Frame1,image=photo3).place(x=250,y=70)

def data_sd(text):
        socket_client.send(text.encode()) 

###########################################################
if __name__=='__main__':
    socket_client=''
    socket_client=socket.socket()
    socket_client.connect(('127.0.0.1',2001))#(('127.0.0.1',2001))#(('192.168.1.12',2001)) #2个框号
    #global ecmd  #二维码接收内容
    elist_sheet=[]
    elist_num=0

    root = tk.Tk()
    root.title('金砖大赛')
    root.geometry('1200x700')
    root.configure(bg='navy')
    tk.Label(root,text="机场人员流调系统",font=("宋体",18),fg='white',bg='navy').place(x=420,y=10) #
    
    def ewm_sheet():
        global elist_sheet
        Frame1.pack_forget()
        Frame4= tk.Frame(root,height=600,width=700,bg="white")
        Frame4.place(x=500,y=50)    
        tk.Label(Frame4,text="最近排查人员信息",font=("黑体",18)).place(x=250,y=10)
        tk.Button(Frame4,text='返回统计图',bg="Skyblue",activebackground='yellow',activeforeground='red',font=("黑体",15),width=15,height=1,command=Frame4.place_forget).place(x=200,y=550)
        tk.Button(Frame4,text='退出系统',bg="Skyblue",font=("黑体",15),width=15,height=1,command=root.destroy).place(x=500,y=550)  
        #fig, ax = plt.subplots(1, 1)
        fig = plt.figure(figsize=(3,2)) #表格大小 3*2 英尺
        ax = plt.subplot(111)#1 行1 列 1 子图
        plt.rcParams['font.sans-serif']='simhei'
        # 左侧边栏，如果不需要，在plt.table中注释即可
        # rowLabels 与 rowColours中的数据长度要保持一致，同时和数据中的元素个数保持一致--len(data)
        data_hang=['1','2','3','4','5','6','7','8','9','10']
        Colours_hang =["#377eb8","#377eb8","#377eb8","#377eb8","#377eb8","#377eb8","#377eb8","#377eb8","#377eb8","#377eb8"]
        # 列表头颜色，需要和单条数据长度保持一致--len(data[0])
        # Tom,man,6,36.1,cityN
        Colours_lie = ["#EBB25E","#EBB25E","#EBB25E","#EBB25E","#EBB25E"]
        data_lie=["姓名","性别","年龄","体温","行程"]
        # 左侧结果图数据
        data = [
                [' ', ' ', ' ', ' ', ' ',],
                [' ', ' ', ' ', ' ', ' ',],
                [' ', ' ', ' ', ' ', ' ',],
                [' ', ' ', ' ', ' ', ' ',],
                [' ', ' ', ' ', ' ', ' ',],
                [' ', ' ', ' ', ' ', ' ',],
                [' ', ' ', ' ', ' ', ' ',],
                [' ', ' ', ' ', ' ', ' ',],
                [' ', ' ', ' ', ' ', ' ',],
                [' ', ' ', ' ', ' ', ' ',],
               ]
        for i in range(elist_num):
            data[i][0]=elist_sheet[i*5]
            data[i][1]=elist_sheet[i*5+1] 
            data[i][2]=elist_sheet[i*5+2] 
            data[i][3]=elist_sheet[i*5+3]
            data[i][4]=elist_sheet[i*5+4]
        #data[0][5]=elist_sheet[4] 
        # 取消坐标轴
        ax.axis('off')
        the_table=ax.table(cellText=data,
                colLabels=data_lie,
                colColours=Colours_lie,
                rowLabels=data_hang,
                rowColours=Colours_hang,
                cellLoc='center',
                rowLoc='center',
                loc="center",
                )
        the_table.set_fontsize(11)
        fig.savefig('biao.jpg')
        global photo4
        photo_open4=Image.open('./biao.jpg')
        photo4=photo_open4.resize((600,400))
        photo4=ImageTk.PhotoImage(photo4)
        tk.Label(Frame4,image=photo4).place(x=50,y=50)
  
    Frame1= tk.Frame(root,height=610,width=650,bg="white")
    Frame1.place(x=500,y=50)
    tk.Label(Frame1,text="人员风险信息统计",font=("微软雅黑",18),bg="white").place(x=300,y=20)
    tk.Label(Frame1,text="识别总人数：  个",font=("微软雅黑",15),bg="gray").place(x=20,y=70)
    tk.Label(Frame1,text="低风险人数：  个",font=("微软雅黑",15),bg="lawngreen").place(x=20,y=170)
    tk.Label(Frame1,text="中风险人数：  个",font=("微软雅黑",15),bg="skyblue").place(x=20,y=270)
    tk.Label(Frame1,text="高风险人数：  个",font=("微软雅黑",15),bg="yellow").place(x=20,y=370)
    tk.Label(Frame1,text="隔离区人数：  个",font=("微软雅黑",15),bg="red").place(x=20,y=470)
    tk.Button(Frame1,text='数据监控画面',bg="Skyblue",font=("黑体",12),width=18,height=2,command=ewm_sheet,).place(x=120,y=550)
    tk.Button(Frame1,text='退出系统',bg="Skyblue",font=("黑体",12),width=18,height=2,command=root.destroy).place(x=450,y=550)

    def face_login():
        name,face_id,time_flag=Face()
        #print(name,face_id,time_flag)
        if time_flag==1:
            tk.Label(Frame2,text='     ').place(x=280,y=70)
            tk.Label(Frame2,text='       ').place(x=280,y=120)
            tk.Label(Frame2,text='           ').place(x=280,y=240)
            tk.Label(Frame2,text=face_id,font=("微软雅黑",15)).place(x=280,y=70)
            tk.Label(Frame2,text=name,font=("微软雅黑",15)).place(x=280,y=120)
            tk.Label(Frame2,text='登录成功',font=("微软雅黑",15)).place(x=150,y=240)
            face_img('image')
            data_sd("A,1")
        else:
            tk.Label(Frame2,text='          ',font=("微软雅黑",15)).place(x=280,y=70)
            tk.Label(Frame2,text='          ',font=("微软雅黑",15)).place(x=280,y=120)
            tk.Label(Frame2,text='          ',font=("微软雅黑",15)).place(x=280,y=240)
            tk.Label(Frame2,text='登录失败',font=("微软雅黑",15)).place(x=150,y=240)
            face_img('face')
            data_sd("A,2")  

    def face_xiao():  
        #print(name,face_id)
        tk.Label(Frame2,text='             ',font=("微软雅黑",15)).place(x=280,y=70)
        tk.Label(Frame2,text='             ',font=("微软雅黑",15)).place(x=280,y=120)
        tk.Label(Frame2,text='             ',font=("微软雅黑",15)).place(x=150,y=240)
        face_img('face')
        data_sd("A,0")

    Frame2= tk.Frame(root,height=280,width=400)
    Frame2.place(x=50,y=50)
    tk.Label(Frame2,text="人脸识别",font=("微软雅黑",15)).place(x=130,y=10)
    tk.Label(Frame2,text="FACE ID:",font=("微软雅黑",15)).place(x=170,y=70)
    tk.Label(Frame2,text="NAME:",font=("微软雅黑",15)).place(x=170,y=120)
    btn1 = tk.Button(Frame2,text='人脸登录',font=("黑体",12),bg="LightSeaGreen",width=10,height=1,command=face_login).place(x=80,y=180)
    btn2 = tk.Button(Frame2,text='注销',font=("黑体",12),bg="Gold",width=10,height=1,command=face_xiao).place(x=230,y=180)
    face_img('face')
  
    def ewm_loop():
        #"低风险":{"浙江一区","深圳一区","山东一区","福建一区","广东一区"},
        #B,Tom,man,6,36.1,cityN
        risk={
          "D":{"cityD","cityH","cityL","cityP","cityT","cityX","cityM","cityQ","cityU","cityV","cityY","cityZ"},
          "Z":{"cityC","cityG","cityK","cityO","cityS","cityW"},
          "G":{"cityB","cityF","cityJ","cityN","cityR"},
          "GL":{"cityA","cityE","cityI"},
         }
        global elist_sheet
        global elist_num
        elist_tu=[" ",0,0,0,0,0]  # 0是总人数，第二位是风险地方，后面依次是 隔离，高，中，低
        while True:
            ecmd=socket_client.recv(1024).decode()
            #print(ecmd)
            if ecmd=='ok':
                ecmd=''
                #读二维码
                img=cv2.imread("./img.jpg")
                det=cv2.QRCodeDetector()
                val,a,b=det.detectAndDecode(img)
                elist=val.split(',')
                elist_sheet=elist_sheet+elist
                elist_num=elist_num+1
                #显示二维码信息
                try:
                    tk.Label(Frame3,text="            ",font=("微软雅黑",15)).place(x=220,y=45) 
                    tk.Label(Frame3,text="            ",font=("微软雅黑",15)).place(x=220,y=80)
                    tk.Label(Frame3,text="            ",font=("微软雅黑",15)).place(x=220,y=115)
                    tk.Label(Frame3,text="            ",font=("微软雅黑",15)).place(x=220,y=150)
                    tk.Label(Frame3,text="            ",font=("微软雅黑",15)).place(x=220,y=185)
                    tk.Label(Frame3,text=elist[0],font=("微软雅黑",15)).place(x=220,y=45) 
                    tk.Label(Frame3,text=elist[1],font=("微软雅黑",15)).place(x=220,y=80)
                    tk.Label(Frame3,text=elist[2],font=("微软雅黑",15)).place(x=220,y=115)
                    tk.Label(Frame3,text=elist[3],font=("微软雅黑",15)).place(x=220,y=150)
                    tk.Label(Frame3,text=elist[4],font=("微软雅黑",15)).place(x=220,y=185)
                    print(('B,'+elist[0]+','+elist[1]+','+elist[2]+','+elist[3]+','+elist[4]))
                    data_sd(('B,'+elist[0]+','+elist[1]+','+elist[2]+','+elist[3]+','+elist[4]))
                except:
                    data_sd("diu")
                ewm_img('img')
                #time.sleep(2)
                ##扇形图图的数据 Tom,man,6,36.1,cityN
                elist_tu[1]=elist_tu[1]+1
                print(elist[3])
                if float(elist[3])>37.2 or float(elist[3])<36:
                    elist_tu[0]="geli"
                    elist_tu[5]=elist_tu[5]+1
                else:
                    for key,value in risk.items(): #
                        if elist[4] in value:
                            if key == "D":
                                elist_tu[2]=elist_tu[2]+1
                                elist_tu[0]="low"
                            elif key == "Z":
                                elist_tu[3]=elist_tu[3]+1
                                elist_tu[0]="mid"
                            elif key == "G":
                                elist_tu[4]=elist_tu[4]+1
                                elist_tu[0]="high"
                            elif key == "GL":
                                elist_tu[5]=elist_tu[5]+1
                                elist_tu[0]="geli"
                tk.Label(Frame1,text=elist_tu[1],bg="gray",font=("微软雅黑",15)).place(x=140,y=70)
                tk.Label(Frame1,text=elist_tu[2],bg="lawngreen",font=("微软雅黑",15)).place(x=140,y=170)
                tk.Label(Frame1,text=elist_tu[3],bg="skyblue",font=("微软雅黑",15)).place(x=140,y=270)
                tk.Label(Frame1,text=elist_tu[4],bg="yellow",font=("微软雅黑",15)).place(x=140,y=370)
                tk.Label(Frame1,text=elist_tu[5],bg="red",font=("微软雅黑",15)).place(x=140,y=470)
                #print(('C,'+elist_tu[0]+','+str(elist_tu[1])+','+str(elist_tu[2])+','+str(elist_tu[3])+','+str(elist_tu[4])+','+str(elist_tu[5])))
                data_sd('C,'+elist_tu[0]+','+str(elist_tu[1])+','+str(elist_tu[2])+','+str(elist_tu[3])+','+str(elist_tu[4])+','+str(elist_tu[5]))
                ##########################
                #Figure创建图像对象，figsize指定画布的大小，(宽度,高度)，单位为英寸。
                # dpi 指定绘图对象的分辨率，即每英寸多少个像素，默认值为80
                fig = Figure(figsize=(4, 4), dpi=100)
                # subplot()均等划分画布,如果不想覆盖之前的图，需要使用 add_subplot() 函数
                sxt = fig.add_subplot(111)
                # 解决汉字乱码问题，使用指定的汉字字体类型（此处为黑体）
                plt.rcParams['font.sans-serif']='simhei'
                data=[0,0,0,0]
                data[0]=elist_tu[2]
                data[1]=elist_tu[3]
                data[2]=elist_tu[4]
                data[3]=elist_tu[5]
                data_name=['低风险','中风险','高风险','隔离区']
                data_colors=['green','blue','yellow','red']
                for i in range(4):
                    if data[i]==0:
                        data_name[i]='      '
                sxt.pie(data,labels=data_name,colors=data_colors,autopct='%.1f%%')
                sxt.set_title('风险区分布图')
                fig.savefig('shan.jpg')
                sx_img('shan')
    #初始界面设计
    Frame3= tk.Frame(root,height=280,width=400)
    Frame3.place(x=50,y=380)
    tk.Label(Frame3,text="人员信息识别",font=("微软雅黑",15)).place(x=130,y=10)

    tk.Label(Frame3,text="姓名",font=("微软雅黑",15)).place(x=170,y=45)
    tk.Label(Frame3,text="性别",font=("微软雅黑",15)).place(x=170,y=80)
    tk.Label(Frame3,text="年龄",font=("微软雅黑",15)).place(x=170,y=115)
    tk.Label(Frame3,text="体温",font=("微软雅黑",15)).place(x=170,y=150)
    tk.Label(Frame3,text="行程",font=("微软雅黑",15)).place(x=170,y=185)
    btn1 = tk.Button(Frame3,text='开始排查',font=("黑体",12),bg="green",width=10,height=1,command=lambda:data_sd("start")).place(x=80,y=230)
    btn2 = tk.Button(Frame3,text='停止排查',font=("黑体",12),bg="red",width=10,height=1,command=lambda:data_sd("stop")).place(x=230,y=230)
    ewm_img('ewm')
    ##开线程，不停接收服务端数据
    thread=threading.Thread(target=ewm_loop)
    thread.daemon=True
    thread.start()

    root.mainloop()
