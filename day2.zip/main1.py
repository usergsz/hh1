import cv2
import threading
import socket
import tkinter as tk
import matplotlib.pyplot as plt

from FaceRecognition import Face
from matplotlib.figure import Figure
from PIL import Image,ImageTk
socket_c1=''

def dat_send(text):
    socket_c1.send(text.encode())

if __name__=='__main__':
    socket_c1=socket.socket()
    socket_c1.connect(('127.0.0.1',2001))
    
    root=tk.Tk()
    root.title('金砖比赛')
    root.geometry('1200x700')
    root.configure(bg='navy')
    tk.Label(root,text='机场人员流调信息',font=('微软雅黑',18),fg='white',bg='navy').place(x=420,y=10)
    ################
    #第1个窗体
    frame1=tk.Frame(root,height=610,width=700)
    frame1.place(x=500,y=50)
    tk.Label(frame1,text='识别总人数',font=('微软雅黑',15),bg='gray',height=1,width=15).place(x=10,y=50)
    tk.Label(frame1,text='低风险人数',font=('微软雅黑',15),bg='green',height=1,width=15).place(x=10,y=150)
    tk.Label(frame1,text='中风险人数',font=('微软雅黑',15),bg='blue',height=1,width=15).place(x=10,y=250)
    tk.Label(frame1,text='高风险人数',font=('微软雅黑',15),bg='yellow',height=1,width=15).place(x=10,y=350)
    tk.Label(frame1,text='隔离区人数',font=('微软雅黑',15),bg='red',height=1,width=15).place(x=10,y=450)
    btn1=tk.Button(frame1,text='数据监控画面',font=('微软雅黑',12),bg='skyblue',height=1,width=15).place(x=100,y=510)
    btn2=tk.Button(frame1,text='数据监控画面',font=('微软雅黑',12),bg='skyblue',height=1,width=15).place(x=100,y=510)
    #第2个窗体
    frame2=tk.Frame(root,height=280,width=400)
    frame2.place(x=50,y=50)
    #第3个窗体
    frame3=tk.Frame(root,height=280,width=400)
    frame3.place(x=50,y=380)

    root.mainloop()